﻿// Your web app's Firebase configuration
const firebaseConfig = {
  apiKey: "AIzaSyBuAHtUUI8ubvgi0ihMd_wY0IReNelBCnc",
  authDomain: "vedchatapp-71eac.firebaseapp.com",
  databaseURL: "https://vedchatapp-71eac-default-rtdb.firebaseio.com",
  projectId: "vedchatapp-71eac",
  storageBucket: "vedchatapp-71eac.appspot.com",
  messagingSenderId: "438903987629",
  appId: "1:438903987629:web:70737b7a4fa8a56fc21524"
};
// Initialize Firebase
firebase.initializeApp(firebaseConfig);
